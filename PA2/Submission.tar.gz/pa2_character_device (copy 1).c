

#include<linux/init.h>
#include<linux/module.h>

#include<linux/fs.h>
#include<linux/slab.h>
#include<linux/uaccess.h>

#define BUFFER_SIZE   1024
#define MAJOR_NUMBER  511
#define DEVICE_NAME  "pa2_character_device"

/* Define device_buffer and other global data structures you will need here */
static char* device_buffer;	// using static, may not need to...
unsigned int open_count = 0;
unsigned int close_count = 0;

ssize_t pa2_char_driver_read (struct file *pfile, char __user *buffer, size_t length, loff_t *offset)
{
	/* *buffer is the userspace buffer to where you are writing the data you want to be read from the device file*/
	/* length is the length of the userspace buffer*/
	/* offset will be set to current position of the opened file after read*/
	/* copy_to_user function: source is device_buffer and destination is the userspace buffer *buffer */
	printk(KERN_ALERT "inside %s function\n",__FUNCTION__);	// copied from helloModule.c
	if(sizeof(length) + sizeof(*offset) > BUFFER_SIZE){
		printk(KERN_ALERT "Attempting to read more data than is stored in the buffer. Displaying only data stored in buffer.");
		length = sizeof(device_buffer) - sizeof(*offset);	
	}
	copy_to_user(buffer, device_buffer + *offset, length);
	*offset += length;
	printk(KERN_ALERT "The number of bytes read is: %zu, and the offset at the end of the read is %lld\n", length , *offset);
	return 0;
}



ssize_t pa2_char_driver_write (struct file *pfile, const char __user *buffer, size_t length, loff_t *offset)
{
	/* *buffer is the userspace buffer where you are writing the data you want to be written in the device file*/
	/* length is the length of the userspace buffer*/
	/* current position of the opened file*/
	/* copy_from_user function: destination is device_buffer and source is the userspace buffer *buffer */
	printk(KERN_ALERT "inside %s function\n",__FUNCTION__);	// copied from helloModule.c
// https://linux-kernel-labs.github.io/refs/heads/master/labs/device_drivers.html
	if(sizeof(length) + sizeof(*offset) > BUFFER_SIZE)
		length = sizeof(device_buffer) - sizeof(*offset);	
	if(copy_from_user(device_buffer + *offset, buffer, length))
		return -EFAULT;
	*offset += length;
	printk(KERN_ALERT "Device wrote %zu bytes, new offset = %lld\n", length, *offset);

	return length;
}


int pa2_char_driver_open (struct inode *pinode, struct file *pfile)
{
	/* print to the log file that the device is opened and also print the number of times this device has been opened until now*/
	//MOD_INC_USE_COUNT ... I would like to learn to use this if possible, otherwise, global variables...	
	open_count++;	
	printk(KERN_ALERT "Device has now been opened %d, times\n", open_count);
	return 0;
}

int pa2_char_driver_close (struct inode *pinode, struct file *pfile)
{
	/* print to the log file that the device is closed and also print the number of times this device has been closed until now*/
	close_count++;	
	printk(KERN_ALERT "File closed, # of times closed = %d\n", close_count);
		
	return 0;
}

loff_t pa2_char_driver_seek (struct file *pfile, loff_t offset, int whence)
{
	/* Update open file position according to the values of offset and whence */
// inspiration for code found at: https://www.oreilly.com/library/view/linux-device-drivers/0596000081/ch05s05.html
	loff_t newPosition;
	printk(KERN_ALERT "inside %s function\n",__FUNCTION__);	// copied from helloModule.c
	if(whence == 0)
		newPosition = offset;
	else if(whence == 1)
		newPosition = pfile->f_pos + offset;
	else if(whence == 2)
		newPosition = sizeof(device_buffer) - offset;
	else{
		printk(KERN_ALERT "Entered an improper value for whence in seek function, enter value 0,1,or 2.");
		return EINVAL;	// per linux man7 page, EINVAL = whence is invalid.
	}
	if(newPosition < 0 || newPosition > sizeof(device_buffer)){
		printk(KERN_ALERT "Attempting to seek outside of device buffer memory");
		return -EINVAL;
	}
	pfile->f_pos = newPosition;
	printk(KERN_ALERT "Offset after seeking is now, %lld\n", newPosition);
	return newPosition;
}

struct file_operations pa2_char_driver_file_operations = {

	.owner   = THIS_MODULE,
	/* add the function pointers to point to the corresponding file operations. look at the file fs.h in the linux souce code*/
// copied from fs.h via bootlin.com lines 3515-3519
	.open	 = pa2_char_driver_open,
	.release = pa2_char_driver_close,
	.read	 = pa2_char_driver_read,
	.write 	 = pa2_char_driver_write,
	.llseek  = pa2_char_driver_seek
};

static int pa2_char_driver_init(void)
{
	/* print to the log file that the init function is called.*/
	printk(KERN_ALERT "inside %s function\n",__FUNCTION__);	// copied from helloModule.c
	/* register the device */
	register_chrdev(MAJOR_NUMBER, DEVICE_NAME, &pa2_char_driver_file_operations);
	//allocating device buffer memory
	device_buffer = kmalloc(1024, GFP_KERNEL); // using gfp_kernel as noted in the write up.
	return 0;
}

static void pa2_char_driver_exit(void)
{
	/* print to the log file that the exit function is called.*/
	printk(KERN_ALERT "inside %s function\n",__FUNCTION__);	// copied from helloModule.c
	/* unregister  the device using the register_chrdev() function. */
	unregister_chrdev(MAJOR_NUMBER, DEVICE_NAME);
	//freeing device buffer memory
	kfree(device_buffer);
}

/* add module_init and module_exit to point to the corresponding init and exit function*/
module_init(pa2_char_driver_init);
module_exit(pa2_char_driver_exit);