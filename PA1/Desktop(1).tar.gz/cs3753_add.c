#include <linux/kernel.h>
#include <linux/linkage.h>
#include <linux/uaccess.h> //(copy_to_user header)

asmlinkage long sys_cs3753_add(int a, int b, int* place)

{
	int answer = a + b;
	copy_to_user(place, &answer, sizeof(int));
	printk(KERN_ALERT "Mathematically speaking...%d +  %d = %d.\n",a,b, answer);
	return 0;
}
