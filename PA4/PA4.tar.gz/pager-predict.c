/*
* File: pager-lru.c
* Author:       Andy Sayler
*               http://www.andysayler.com
* Adopted From: Dr. Alva Couch
*               http://www.cs.tufts.edu/~couch/
*
* Project: CSCI 3753 Programming Assignment 4
* Create Date: Unknown
* Modify Date: 2012/04/03
* Description:
* 	This file contains an lru pageit
*      implmentation.
*/

#include <stdlib.h>

#include "simulator.h"

void pageit(Pentry q[MAXPROCESSES]) {

  /* This file contains the stub for an LRU pager */
  /* You may need to add/remove/modify any part of this file */

  /* Static vars */
  static int initialized = 0;
  static int tick = 1; // artificial time
  static int timestamps[MAXPROCESSES][MAXPROCPAGES];

  /* Local vars */
  int proctmp;
  int pagetmp;

  /* initialize static vars on first run */
  if(!initialized){
    for(proctmp = 0; proctmp < MAXPROCESSES; proctmp++)
      for(pagetmp = 0; pagetmp < MAXPROCPAGES; pagetmp++)
        timestamps[proctmp][pagetmp] = 0;
        // pagein(0,0);
        // pagein(0,1);
        // pagein(0,2);
        // pagein(0,3);
        // pagein(0,4);
    initialized = 1;
  } /* end if */

  /* TODO: Implement LRU Paging */
  for(int proctmp=0; proctmp<MAXPROCESSES; proctmp++) {
    /* Is process inactive? */
    if(!q[proctmp].active)
      continue;
    else{
      int pc = q[proctmp].pc; 		      // The value of the program counter for the process.
      int page = pc/PAGESIZE; 		  // The current page
      // if( pc == 504 || pc == 1130  || pc == 1534  || pc == 1684 || q[proctmp].pages[0] == 0){
      //   pageout(proctmp, (page -1));
      //   pagein(proctmp, 0);
      // }
      switch(page){
        case 0:
          pagein(proctmp, 1);
          pagein(proctmp, 2);
          pagein(proctmp, 3);
        // case 3:
        //   pageout(proctmp, 2);
        //   pagein(proctmp, 0);
        case 14:
          pageout(proctmp, 13);
          pagein(proctmp, 0);
        default:
          if(!q[proctmp].pages[page]){     /* Is page swaped-out? */
            if(!pagein(proctmp,page)) {    /* Try to swap in */
                                        /* If swapping fails, swap out another page */
              int LRUPage = tick;       // variable to store the least recently used page. Should always end up lower than tick.
              for(pagetmp = 0; pagetmp < MAXPROCPAGES; pagetmp++){                   // traverse all of the pages for the process.
                // if the page is currently swapped in, and its timestamps is lower than the last timestamp referenced, store the new lowest index.
                if(q[proctmp].pages[pagetmp] && timestamps[proctmp][pagetmp] < LRUPage)
                  LRUPage = pagetmp;
              } /* end */

              pageout(proctmp, LRUPage); // swap out the least recently used page.
              /* Break loop after finding first active process */
              break;
            } /* end if */
          } /* end if */
      } /* end switch */
      timestamps[proctmp][page] = tick;
    } /* end else */
  } /* end */
  tick++;   /* advance time for next pageit iteration */
} /* end  */
