#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <stdlib.h> // need this for malloc

int main()
{
	int a, b;
	long callAdd;
	printf("Enter the first number value:");
	scanf("%d", &a);
	printf("Enter the second value:");
	scanf("%d", &b);
	int *location = malloc(sizeof(int));
	callAdd = syscall(334, a, b, location);
	printf("System call returned # %ld \n", callAdd);
	return callAdd;
}
