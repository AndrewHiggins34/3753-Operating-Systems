#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//including the headers below base on man7.org page on open command.
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
// including the header below based on man7.org page on read command.
#include <unistd.h>

#define DEVICE_NAME "/dev/pa2_character_device"

void menu(){
    printf("Press r to read from device.\n");
    printf("Press w to write to the device.\n");
    printf("Press s to seek into the device.\n");
    printf("Press e to exit from the device.\n");
    printf("Press anything else to keep reading or writing from the device.\n");
    printf("Enter command:\n");
}

int main()
{
        int file = open(DEVICE_NAME, O_RDWR);	// O_RDWR flag is read.write privileges per linux-man7
        int power = 1;
        char buffer[1024];
        	
    printf("Welcome to today's Interactive Test Program. I am your host, please standby for todays options.\n");
    menu();
    char c;
    while(power){
    scanf(" %c", &c);
        switch(c){
        case 'r':{
	    size_t length;
            printf("Enter the number of bytes you want to read:\n");
            scanf(" %zu", &length);
	    //buffer = malloc(length);
            if(read(file, buffer, length) < 0)
                write(2, "An error occurred in the read.\n", 31);
            
            printf("Data read from the device: %s\n", buffer);
	    menu();
            break;
        }
        case 'w':{
            printf("Enter data you want to write to the device:\n");
            scanf(" %[^\n]%*c", buffer);
                if (!(write(file, buffer , strlen(buffer)))){
                    write(2, "There was an error writing to standard out\n", 44);
                    return -1;
                }
	    menu();
            break;
        }
        case 's':{
            printf("Enter an offset value:\n");
	    unsigned long offset;
	    unsigned int whence;
            scanf(" %lu", &offset);
            printf("Enter a value for whence (third parameter):\n");
            scanf(" %u", &whence);
            lseek(file, offset, whence);
	    menu();
            break;
        }
        case 'e':{
            power = 0;
            break;
        }
        default:{
            printf("Enter appropriate character.\n");
	    menu();
            break;
        }
    }
    }
    
    return 0;
}



