#define _GNU_SOURCE /* See feature_test_macros(7) */
#include <unistd.h>
#include <sys/syscall.h> /* For Sys_xxx definitions */
/* headers came from: https://manpages.debian.org/stretch/manpages-dev/syscall.2.en.html */
#include <stdio.h> // adding this due to printf error

//using code model from recitation
int main(int argc, char **argv){
        long callHello;
        callHello = syscall (333);
        printf("System call returned # %ld. \n", callHello);
        return callHello;
}

